import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

const f0 = 437550000.0; // ISS SSTV downlink (راجع التردد قبل كل حدث)
const rad = math.pi / 180;
const minEl = 5.0; // أقل ارتفاع يُعتبر مرورًا صالحًا (درجات)
const appId = 'com.astro.iss_sstv_tracker';
const cream = Color(0xFFF5EFDC), ink = Color(0xFF111111);

class St {
  final String n, u, cc;
  final bool ws;
  final double? la, lo;
  final bool approx; // إحداثيات تقريبية (على مستوى المدينة/الدولة) — صحّحها إن عرفت الموقع
  bool? ok;
  St(this.n, this.u, {this.cc = '', this.ws = false, this.la, this.lo, this.approx = false});
  double get lat => la ?? 52.129;
  double get lon => lo ?? 5.019;
}


final stations = <St>[
  St('Maarssen NL — الأساسية', 'http://radarmaarssen.nl:8073/', cc: 'NL', la: 52.129, lo: 5.019),
  St('Maasbree WebSDR NL — احتياطي', 'http://sdr.websdrmaasbree.nl:8909/', cc: 'NL', ws: true, la: 51.35, lo: 6.05),
  St('fm-tuner ZZE3 NL', 'https://fm-tuner.nl/sdr-zze3/', cc: 'NL', la: 52.1, lo: 5.3, approx: true),
  St('DC7JZB Berlin', 'http://90.187.72.177:8073/', cc: 'DE', la: 52.408, lo: 13.404),
  St('DB0BLX Berlin', 'http://hamnetberlin.duckdns.org:4038/', cc: 'DE', la: 52.510, lo: 13.394),
  St('Dannenberg DE', 'http://hgdyn.spdns.org:8099/', cc: 'DE', la: 53.107, lo: 11.107),
  St('DC5DM Netphen DE', 'http://www.dc5dm.de/webrx/', cc: 'DE', la: 50.886, lo: 8.139),
  St('Hahnenkamm DE', 'http://sdr-hahnenkamm.de:8071/', cc: 'DE', la: 49.017, lo: 10.749),
  St('Grzegórzki PL', 'http://sdr.noip.pl:8073/', cc: 'PL', la: 50.018, lo: 19.979),
  St('SR4DON Olsztyn PL', 'https://1.websdr.jestok.com/', cc: 'PL', la: 53.78, lo: 20.49, approx: true),
  St('IW2KPL IT', 'http://www.dxcluster.world:8074/', cc: 'IT', la: 45.46, lo: 9.19, approx: true),
];


class V {
  final double x, y, z;
  V(this.x, this.y, this.z);
  V operator -(V o) => V(x - o.x, y - o.y, z - o.z);
  double get l => math.sqrt(x * x + y * y + z * z);
  double dot(V o) => x * o.x + y * o.y + z * o.z;
}

V obsV(double la, double lo) => V(6371 * math.cos(la * rad) * math.cos(lo * rad),
    6371 * math.cos(la * rad) * math.sin(lo * rad), 6371 * math.sin(la * rad));

class Pass {
  final double aos, los, maxEl;
  Pass(this.aos, this.los, this.maxEl);
}

class Look {
  final double el, az, rng;
  Look(this.el, this.az, this.rng);
}

/// مدار شبه دائري من TLE + انجراف J2 (تقريبي، مناسب للمرورات وDoppler).
class Orb {
  late final double inc, raan, argp, m0, n, ep, a, k;
  Orb(String l1, String l2) {
    double d(int s, int e) => double.parse(l2.substring(s, e).trim());
    inc = d(8, 16) * rad;
    raan = d(17, 25) * rad;
    argp = d(34, 42) * rad;
    m0 = d(43, 51) * rad;
    n = d(52, 63) * 2 * math.pi / 86400;
    final y = int.parse(l1.substring(18, 20));
    ep = DateTime.utc(y < 57 ? 2000 + y : 1900 + y).millisecondsSinceEpoch / 1000 +
        (double.parse(l1.substring(20, 32)) - 1) * 86400;
    a = math.pow(398600.4418 / (n * n), 1 / 3).toDouble();
    k = 1.5 * 1.08263e-3 * math.pow(6378.137 / a, 2).toDouble();
  }

  V ecef(double t) {
    final dt = t - ep;
    final c = math.cos(inc);
    final om = raan - k * n * c * dt;
    final u = m0 + argp + n * (1 + k * (4 * c * c - 1)) * dt;
    final x = a * (math.cos(om) * math.cos(u) - math.sin(om) * c * math.sin(u));
    final y = a * (math.sin(om) * math.cos(u) + math.cos(om) * c * math.sin(u));
    final z = a * math.sin(inc) * math.sin(u);
    final g = ((280.46061837 + 360.98564736629 * (t / 86400 + 2440587.5 - 2451545.0)) % 360) * rad;
    return V(x * math.cos(g) + y * math.sin(g), -x * math.sin(g) + y * math.cos(g), z);
  }

  LatLng ll(double t) {
    final s = ecef(t);
    return LatLng(math.asin(s.z / s.l) / rad, math.atan2(s.y, s.x) / rad);
  }

  double alt(double t) => ecef(t).l - 6371;

  double el(double t, V ob) {
    final r = ecef(t) - ob;
    return math.asin(r.dot(ob) / (r.l * ob.l)) / rad;
  }

  /// الارتفاع والسمت والمسافة من موقع المراقب.
  Look look(double t, double la, double lo) {
    final r = ecef(t) - obsV(la, lo);
    final sl = math.sin(la * rad), cl = math.cos(la * rad);
    final so = math.sin(lo * rad), co = math.cos(lo * rad);
    final e = -so * r.x + co * r.y;
    final nn = -sl * co * r.x - sl * so * r.y + cl * r.z;
    final u = cl * co * r.x + cl * so * r.y + sl * r.z;
    final rng = r.l;
    return Look(math.asin(u / rng) / rad, (math.atan2(e, nn) / rad + 360) % 360, rng);
  }

  double dop(double t, V ob) {
    final r1 = (ecef(t) - ob).l, r2 = (ecef(t + 1) - ob).l;
    return f0 * (1 - (r2 - r1) / 299792.458);
  }

  /// لحظة عبور الارتفاع [lv] بين a وb بالتنصيف (دقة أقل من ثانية).
  double _cross(V ob, double t1, double t2, double lv) {
    final sideA = el(t1, ob) > lv;
    for (int i = 0; i < 12; i++) {
      final m = (t1 + t2) / 2;
      if ((el(m, ob) > lv) == sideA) {
        t1 = m;
      } else {
        t2 = m;
      }
    }
    return (t1 + t2) / 2;
  }

  List<Pass> passes(double la, double lo, double t0, {double hours = 48}) {
    final ob = obsV(la, lo);
    final out = <Pass>[];
    double? aos;
    double mx = 0;
    double pt = t0, pe = el(t0, ob);
    if (pe > minEl) {
      aos = t0;
      mx = pe;
    }
    for (double t = t0 + 20; t < t0 + hours * 3600; t += 20) {
      final e = el(t, ob);
      if (aos == null && e > minEl && pe <= minEl) aos = _cross(ob, pt, t, minEl);
      if (e > minEl) mx = math.max(mx, e);
      if (aos != null && e <= minEl && pe > minEl) {
        out.add(Pass(aos, _cross(ob, pt, t, minEl), mx));
        aos = null;
        mx = 0;
      }
      pt = t;
      pe = e;
    }
    return out;
  }
}

/// يُحقن في كل صفحة: يلتقط الصوت الخارج من Web Audio (OpenWebRX / WebSDR)
/// ويرسله إلى التطبيق كـ PCM عند طلب التسجيل.
const hookJs = r'''
(function(){
if(window.__issHook)return;window.__issHook=1;
var st={on:false,ctx:null};
var oc=AudioNode.prototype.connect;
function mk(ctx){
  var sp=ctx.createScriptProcessor(4096,1,1),mu=ctx.createGain();mu.gain.value=0;
  sp.onaudioprocess=function(e){
    if(!st.on)return;
    var d=e.inputBuffer.getChannelData(0),n=d.length,b=new Uint8Array(n*2),v=new DataView(b.buffer);
    for(var i=0;i<n;i++){var x=d[i];x=x>1?1:(x<-1?-1:x);v.setInt16(i*2,x<0?x*32768:x*32767,true);}
    var s='';for(var j=0;j<b.length;j+=8192){s+=String.fromCharCode.apply(null,b.subarray(j,j+8192));}
    Rec.postMessage('D'+btoa(s));
  };
  oc.call(sp,mu);oc.call(mu,ctx.destination);
  return sp;
}
AudioNode.prototype.connect=function(dest){
  var r=oc.apply(this,arguments);
  try{
    if(dest&&window.AudioDestinationNode&&dest instanceof AudioDestinationNode&&this.context===dest.context){
      if(!dest.__sp){dest.__sp=mk(dest.context);st.ctx=dest.context;}
      if(!this.__tap&&this!==dest.__sp){this.__tap=1;oc.call(this,dest.__sp);}
    }
  }catch(e){}
  return r;
};
window.__issRec={
  start:function(){
    if(!st.ctx){Rec.postMessage('N');return;}
    try{if(st.ctx.state==='suspended')st.ctx.resume();}catch(e){}
    Rec.postMessage('S'+st.ctx.sampleRate);st.on=true;
  },
  stop:function(){st.on=false;}
};
})();
''';

/// محاولة تشغيل الصوت تلقائيًا (OpenWebRX يحتاج نقرة على شاشة البداية).
const autoStartJs = r'''
(function(){
var ws=WS_FLAG;
function go(){
  var e=document.getElementById('openwebrx-big-grey');if(e){e.click();return;}
  if(ws)return;
  var c=document.querySelectorAll('button,div,span,a');
  for(var i=0;i<c.length;i++){
    var t=(c[i].innerText||'').trim().toLowerCase();
    if(c[i].children.length<3&&t.length<40&&/^(start|click to start|tap to start|start openwebrx)/.test(t)){c[i].click();return;}
  }
}
setTimeout(go,2500);setTimeout(go,6000);
})();
''';

final fln = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzd.initializeTimeZones();
  await fln.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  await fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
  runApp(MaterialApp(
    title: 'ISS SSTV',
    debugShowCheckedModeBanner: false,
    themeMode: ThemeMode.system, // يتبع نظام الجهاز
    theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: ink, surface: cream),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: cream),
        appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: cream)),
    darkTheme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange, brightness: Brightness.dark, surface: ink),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF1C1C1C)),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF1C1C1C), foregroundColor: cream)),
    builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
    home: const Home(),
  ));
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _S();
}

class _S extends State<Home> {
  int tab = 0;
  Orb? o;
  St sel = stations[0];
  List<Pass> ps = [];
  bool auto = true, listening = false, recording = false;
  String err = '';
  double? cmd;
  final log = <String>[];
  late final WebViewController wc;
  SharedPreferences? sp;
  Timer? tk;

  // التسجيل
  IOSink? _pcmSink;
  File? _pcmFile;
  int _recBytes = 0, _recRate = 48000;
  DateTime? _recStart;
  String _recName = '';
  List<File> recs = [];

  // كاش مسار الخريطة (يُعاد حسابه كل 30 ثانية فقط)
  double _trackT = 0;
  List<List<LatLng>> _past = [], _fut = [];
  LatLng mapCenter = LatLng(45, 10);
  double mapZoom = 2.5;

  double get now => DateTime.now().millisecondsSinceEpoch / 1000;
  V get ob => obsV(sel.lat, sel.lon);

  @override
  void initState() {
    super.initState();
    wc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Rec', onMessageReceived: (m) => _onRec(m.message));
    final p = wc.platform;
    if (p is AndroidWebViewController) p.setMediaPlaybackRequiresUserGesture(false);
    wc.setNavigationDelegate(NavigationDelegate(
      onPageStarted: (_) => wc.runJavaScript(hookJs),
      onPageFinished: (_) {
        wc.runJavaScript(hookJs);
        wc.runJavaScript(autoStartJs.replaceFirst('WS_FLAG', sel.ws.toString()));
      },
    ));
    _init();
    _check();
    _loadRecs();
    int i = 0;
    tk = Timer.periodic(const Duration(seconds: 1), (_) {
      i++;
      if (listening && auto && o != null && !sel.ws && i % 2 == 0) {
        final tg = (o!.dop(now, ob) / 100).round() * 100.0;
        final nc = cmd == null ? tg : cmd! + (tg - cmd!).clamp(-300.0, 300.0);
        final r = (nc / 100).round() * 100.0;
        if (r != cmd) {
          cmd = r;
          log.insert(0, '${DateTime.now().toString().substring(11, 19)}  ${(r / 1e6).toStringAsFixed(4)} MHz');
          if (log.length > 50) log.removeLast();
          wc.runJavaScript("location.hash='#freq=${r.round()},mod=nfm'");
        }
      }
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    tk?.cancel();
    _pcmSink?.close();
    WakelockPlus.disable();
    super.dispose();
  }

  void _check() {
    for (final s in stations) {
      http.get(Uri.parse(s.u)).timeout(const Duration(seconds: 6)).then((r) {
        if (mounted) setState(() => s.ok = r.statusCode < 400);
      }).catchError((_) {
        if (mounted) setState(() => s.ok = false);
      });
    }
  }

  Future<void> _init() async {
    sp = await SharedPreferences.getInstance();
    final i = sp!.getInt('sel') ?? 0;
    if (i >= 0 && i < stations.length) sel = stations[i];
    await loadTle();
  }

  Orb? _parseTle(String body) {
    final l = body.split('\n').map((e) => e.trim()).toList();
    final a = l.where((e) => e.startsWith('1 ') && e.length >= 62).toList();
    final b = l.where((e) => e.startsWith('2 ') && e.length >= 63).toList();
    if (a.isEmpty || b.isEmpty) return null;
    return Orb(a.first, b.first);
  }

  /// يستخدم TLE المخزَّن إن كان أحدث من 6 ساعات، وإلا يجلب من CelesTrak،
  /// وعند الفشل يرجع للمخزَّن مهما كان عمره.
  Future<void> loadTle() async {
    final cached = sp?.getString('tle');
    final age = DateTime.now().millisecondsSinceEpoch - (sp?.getInt('tle_t') ?? 0);
    try {
      if (cached != null && age < 6 * 3600 * 1000) {
        final c = _parseTle(cached);
        if (c != null) {
          o = c;
          err = '';
          await refresh();
          return;
        }
      }
      final r = await http
          .get(Uri.parse('https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=tle'))
          .timeout(const Duration(seconds: 15));
      final fresh = _parseTle(r.body);
      if (fresh == null) throw Exception('رد غير صالح');
      await sp?.setString('tle', r.body);
      await sp?.setInt('tle_t', DateTime.now().millisecondsSinceEpoch);
      o = fresh;
      err = '';
    } catch (e) {
      final c = cached == null ? null : _parseTle(cached);
      if (c != null) {
        o = c;
        err = 'تعذر تحديث TLE — استُخدمت نسخة مخزَّنة (قد تقل الدقة)';
      } else {
        if (mounted) setState(() => err = 'تعذر تحميل TLE: $e');
        return;
      }
    }
    await refresh();
  }

  Future<void> _sched(int id, String title, String body, double when) async {
    try {
      await fln.zonedSchedule(
          id,
          title,
          body,
          tz.TZDateTime.from(DateTime.fromMillisecondsSinceEpoch((when * 1000).round()), tz.UTC),
          const NotificationDetails(
              android: AndroidNotificationDetails('iss', 'مرور ISS', importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } catch (_) {}
  }

  Future<void> refresh() async {
    if (o == null) return;
    ps = o!.passes(sel.lat, sel.lon, now);
    try {
      await fln.cancelAll();
    } catch (_) {}
    int id = 1;
    for (final p in ps.take(5)) {
      if (p.aos - 1800 > now) {
        await _sched(id++, 'ISS بعد 30 دقيقة',
            'ستمر ISS فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°. جهّز الاستماع على ${(f0 / 1e6).toStringAsFixed(3)}', p.aos - 1800);
      }
      if (p.aos > now) {
        await _sched(id++, 'ISS تبدأ الآن', 'بدأ المرور فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°', p.aos);
      }
    }
    if (mounted) setState(() {});
  }

  void listen() {
    if (recording) stopRec();
    final f = o?.dop(now, ob) ?? f0;
    final u = sel.ws ? '${sel.u}?tune=${(f / 1e6).toStringAsFixed(3)}fm' : '${sel.u}#freq=${f.round()},mod=nfm';
    wc.loadRequest(Uri.parse(u));
    WakelockPlus.enable(); // يُبقي الشاشة شغّالة كي لا يتوقف الصوت
    setState(() {
      listening = true;
      cmd = null;
    });
  }

  Future<void> stop() async {
    if (recording) await stopRec();
    wc.loadRequest(Uri.parse('about:blank'));
    WakelockPlus.disable();
    if (mounted) {
      setState(() {
        listening = false;
        cmd = null;
      });
    }
  }

  void pick(St s) {
    if (listening) stop();
    sel = s;
    sp?.setInt('sel', stations.indexOf(s));
    refresh();
    setState(() => tab = 0);
  }

  // ───────────── التسجيل ─────────────

  String _2(int n) => n.toString().padLeft(2, '0');
  String _mmss(int s) => '${_2(s ~/ 60)}:${_2(s % 60)}';

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<Directory> _recDir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/recordings');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<void> _loadRecs() async {
    try {
      final d = await _recDir();
      final l = d.listSync().whereType<File>().where((f) => f.path.endsWith('.wav')).toList();
      l.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      if (mounted) setState(() => recs = l);
    } catch (_) {}
  }

  Uint8List _wavHeader(int dataLen, int rate) {
    final b = ByteData(44);
    void s(int o, String t) {
      for (var i = 0; i < t.length; i++) {
        b.setUint8(o + i, t.codeUnitAt(i));
      }
    }

    s(0, 'RIFF');
    b.setUint32(4, 36 + dataLen, Endian.little);
    s(8, 'WAVE');
    s(12, 'fmt ');
    b.setUint32(16, 16, Endian.little);
    b.setUint16(20, 1, Endian.little); // PCM
    b.setUint16(22, 1, Endian.little); // أحادي
    b.setUint32(24, rate, Endian.little);
    b.setUint32(28, rate * 2, Endian.little);
    b.setUint16(32, 2, Endian.little);
    b.setUint16(34, 16, Endian.little);
    s(36, 'data');
    b.setUint32(40, dataLen, Endian.little);
    return b.buffer.asUint8List();
  }

  void _onRec(String m) {
    if (m.isEmpty) return;
    final t = m[0], p = m.substring(1);
    if (t == 'D') {
      final sink = _pcmSink;
      if (recording && sink != null) {
        final bytes = base64Decode(p);
        sink.add(bytes);
        _recBytes += bytes.length;
      }
    } else if (t == 'S') {
      _recRate = int.tryParse(p) ?? 48000;
    } else if (t == 'N') {
      _cancelRec('لا يوجد صوت للتسجيل بعد — ابدأ الاستماع وانتظر حتى يعمل الصوت ثم أعد المحاولة');
    }
  }

  Future<void> startRec() async {
    if (!listening || recording) return;
    try {
      final d = await _recDir();
      final ts = DateTime.now();
      _recName = 'iss_${ts.year}${_2(ts.month)}${_2(ts.day)}_${_2(ts.hour)}${_2(ts.minute)}${_2(ts.second)}';
      _pcmFile = File('${d.path}/$_recName.pcm');
      _pcmSink = _pcmFile!.openWrite();
      _recBytes = 0;
      _recStart = ts;
      setState(() => recording = true);
      await wc.runJavaScript('window.__issRec?window.__issRec.start():Rec.postMessage("N")');
      Future.delayed(const Duration(seconds: 5), () {
        if (recording && _recBytes == 0) {
          _cancelRec('تعذّر التقاط الصوت من هذه المحطة (لا يصل صوت للتسجيل)');
        }
      });
    } catch (e) {
      _cancelRec('تعذّر بدء التسجيل: $e');
    }
  }

  Future<void> _cancelRec(String msg) async {
    if (!recording) return;
    recording = false;
    final sink = _pcmSink, f = _pcmFile;
    _pcmSink = null;
    _pcmFile = null;
    try {
      await wc.runJavaScript('window.__issRec&&window.__issRec.stop()');
      await sink?.close();
      await f?.delete();
    } catch (_) {}
    if (mounted) setState(() {});
    _snack(msg);
  }

  Future<void> stopRec() async {
    if (!recording) return;
    recording = false;
    try {
      await wc.runJavaScript('window.__issRec&&window.__issRec.stop()');
    } catch (_) {}
    final sink = _pcmSink, pcm = _pcmFile;
    _pcmSink = null;
    _pcmFile = null;
    if (sink == null || pcm == null) {
      if (mounted) setState(() {});
      return;
    }
    try {
      await sink.flush();
      await sink.close();
      if (_recBytes == 0) {
        await pcm.delete();
        _snack('لم يُسجَّل أي صوت');
      } else {
        final wav = File('${pcm.parent.path}/${_recName}_${_recRate}hz.wav');
        final out = wav.openWrite();
        out.add(_wavHeader(_recBytes, _recRate));
        await out.addStream(pcm.openRead());
        await out.close();
        await pcm.delete();
        _snack('تم حفظ التسجيل — تبويب «التسجيلات»');
      }
    } catch (e) {
      _snack('تعذّر حفظ التسجيل: $e');
    }
    await _loadRecs();
    if (mounted) setState(() {});
  }

  String _recTitle(File f) => f.path.split('/').last;

  String _recInfo(File f) {
    final len = f.lengthSync();
    final m = RegExp(r'_(\d+)hz').firstMatch(_recTitle(f));
    final rate = int.tryParse(m?.group(1) ?? '') ?? 48000;
    final secs = ((len - 44) / (rate * 2)).round();
    return 'المدة ${_mmss(secs < 0 ? 0 : secs)}  •  ${(len / 1048576).toStringAsFixed(1)} MB  •  ${f.lastModifiedSync().toString().substring(0, 16)}';
  }

  Future<void> _del(File f) async {
    try {
      await f.delete();
    } catch (_) {}
    await _loadRecs();
  }

  // ───────────── واجهة ─────────────

  String fmt(double t) => DateTime.fromMillisecondsSinceEpoch((t * 1000).round()).toString().substring(5, 16);

  String dur(double s) {
    s = s.abs();
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, c = (s % 60).floor();
    return h > 0 ? '$hس ${m}د' : '$mد ${c}ث';
  }

  Color _dot(St s) => s.ok == null ? Colors.grey : (s.ok! ? Colors.green : Colors.red);

  Widget _card(String title, IconData ic, List<Widget> kids) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(ic, size: 18),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 10),
            ...kids,
          ]),
        ),
      );

  Widget _stat(String l, String v) => Expanded(
        child: Column(children: [
          Text(v, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(l, style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
        ]),
      );

  Widget listenTab() {
    final t = now;
    final f = o?.dop(t, ob) ?? f0;
    final lk = o?.look(t, sel.lat, sel.lon);
    final next = ps.where((p) => p.los > t).toList();
    String cd = 'لا توجد مرورات قادمة خلال 48 ساعة';
    double? prog;
    bool live = false;
    if (o == null) {
      cd = err.isEmpty ? 'جارٍ تحميل مدار ISS…' : err;
    } else if (next.isNotEmpty) {
      final p = next.first;
      if (p.aos <= t) {
        live = true;
        cd = '● المرور جارٍ — ينتهي بعد ${dur(p.los - t)}';
        prog = ((t - p.aos) / (p.los - p.aos)).clamp(0.0, 1.0).toDouble();
      } else {
        cd = 'المرور القادم بعد ${dur(p.aos - t)}';
      }
    }
    return ListView(padding: const EdgeInsets.all(12), children: [
      _card('المحطة', Icons.cell_tower, [
        Row(children: [
          Icon(Icons.circle, size: 12, color: _dot(sel)),
          const SizedBox(width: 8),
          Expanded(child: Text(sel.n, style: const TextStyle(fontSize: 16))),
          OutlinedButton(onPressed: () => setState(() => tab = 1), child: const Text('تغيير')),
        ]),
        if (sel.ws)
          const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('محطة WebSDR: يُضبط التردد عند البدء فقط (بدون ضبط Doppler تلقائي).', style: TextStyle(fontSize: 12))),
      ]),
      _card('المرور والتردد', Icons.satellite_alt, [
        Text(cd, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: live ? Colors.green : null)),
        if (prog != null) Padding(padding: const EdgeInsets.only(top: 8), child: LinearProgressIndicator(value: prog)),
        const SizedBox(height: 12),
        Row(children: [
          _stat('Doppler (MHz)', (f / 1e6).toStringAsFixed(4)),
          _stat('الارتفاع', lk == null ? '—' : '${lk.el.toStringAsFixed(1)}°'),
          _stat('السمت', lk == null ? '—' : '${lk.az.toStringAsFixed(0)}°'),
          _stat('المسافة (كم)', lk == null ? '—' : '${lk.rng.round()}'),
        ]),
        if (lk != null)
          Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(lk.el > 0 ? '● ISS فوق الأفق الآن' : '○ ISS تحت الأفق', style: const TextStyle(fontSize: 12))),
      ]),
      _card('الاستماع والتسجيل', Icons.headphones, [
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            value: auto,
            onChanged: sel.ws ? null : (v) => setState(() => auto = v),
            title: const Text('ضبط Doppler تلقائيًا')),
        Row(children: [
          Expanded(
              child: FilledButton.icon(
                  onPressed: listen,
                  icon: Icon(listening ? Icons.refresh : Icons.play_arrow),
                  label: Text(listening ? 'إعادة الاتصال' : 'ابدأ الاستماع'))),
          if (listening) ...[
            const SizedBox(width: 8),
            OutlinedButton.icon(onPressed: stop, icon: const Icon(Icons.stop), label: const Text('إيقاف')),
          ],
        ]),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: FilledButton.tonalIcon(
            onPressed: listening ? (recording ? stopRec : startRec) : null,
            icon: Icon(recording ? Icons.stop_circle : Icons.fiber_manual_record, color: Colors.red),
            label: Text(recording
                ? 'إيقاف التسجيل  ${_mmss(DateTime.now().difference(_recStart ?? DateTime.now()).inSeconds)}'
                : 'تسجيل الصوت'),
          ),
        ),
        if (listening)
          const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                  'لوحة المحطة تظهر أسفل الشاشة. إن لم يبدأ الصوت اضغط عليها (زر Start)، '
                  'وإن كانت المحطة لا تغطي 70cm غيّر الـ Profile من اللوحة نفسها. الشاشة تبقى مضاءة أثناء الاستماع.',
                  style: TextStyle(fontSize: 12))),
      ]),
      _card('المرورات القادمة', Icons.event, [
        if (next.isEmpty) const Text('—'),
        for (final p in next.take(6))
          ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: Text('${fmt(p.aos)} → ${fmt(p.los)}'),
              subtitle: Text('أقصى ارتفاع ≈ ${p.maxEl.round()}°  •  المدة ${dur(p.los - p.aos)}')),
        const Text('الإشعارات: قبل 30 دقيقة وعند بداية المرور.', style: TextStyle(fontSize: 12)),
      ]),
      if (log.isNotEmpty)
        _card('سجل الترددات المرسلة', Icons.history, [
          for (final l in log.take(8)) Text(l, textDirection: TextDirection.ltr),
        ]),
    ]);
  }

  Widget stationsTab() {
    const names = {'NL': 'هولندا', 'DE': 'ألمانيا', 'PL': 'بولندا', 'IT': 'إيطاليا'};
    final groups = <String, List<St>>{};
    for (final s in stations) {
      groups.putIfAbsent(s.cc, () => []).add(s);
    }
    return ListView(padding: const EdgeInsets.all(12), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Expanded(
                child: Text(
                    'النقطة الخضراء تعني أن صفحة المحطة تُفتح فقط. أغلب المستقبلات العامة لا تغطي 437.55 MHz (نطاق 70cm)، '
                    'وبعضها يحتاج تغيير الـ Profile يدويًا من لوحة الاستماع. علامة (≈) = إحداثيات تقريبية.',
                    style: TextStyle(fontSize: 12))),
            IconButton(
                tooltip: 'إعادة فحص المحطات',
                icon: const Icon(Icons.refresh),
                onPressed: () {
                  setState(() {
                    for (final s in stations) {
                      s.ok = null;
                    }
                  });
                  _check();
                }),
          ]),
        ),
      ),
      for (final e in groups.entries) ...[
        Padding(
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 4),
            child: Text(names[e.key] ?? e.key, style: const TextStyle(fontWeight: FontWeight.bold))),
        for (final s in e.value)
          Card(
            child: ListTile(
              selected: s == sel,
              leading: Icon(Icons.circle, size: 14, color: _dot(s)),
              title: Text(s.approx ? '${s.n} ≈' : s.n),
              subtitle: Text(
                  '${s.ws ? "WebSDR" : "OpenWebRX"}  •  ${s.ok == null ? "جارٍ الفحص…" : (s.ok! ? "الصفحة تعمل" : "لا تستجيب")}'),
              trailing: s == sel ? const Icon(Icons.check_circle) : null,
              onTap: () => pick(s),
            ),
          ),
      ],
    ]);
  }

  List<List<LatLng>> _segs(List<LatLng> pts) {
    final lines = <List<LatLng>>[[]];
    for (final p in pts) {
      if (lines.last.isNotEmpty && (p.longitude - lines.last.last.longitude).abs() > 180) lines.add([]);
      lines.last.add(p);
    }
    return lines;
  }

  Widget mapTab() {
    if (o == null) return Center(child: Text(err.isEmpty ? 'جارٍ تحميل مدار ISS...' : err));
    final t = now;
    if (t - _trackT > 30) {
      _trackT = t;
      _past = _segs([for (double d = -2700; d <= 0; d += 60) o!.ll(t + d)]);
      _fut = _segs([for (double d = 0; d <= 6000; d += 60) o!.ll(t + d)]);
    }
    final pos = o!.ll(t);
    final h = o!.alt(t);
    final foot = 6371 * math.acos(6371 / (6371 + h)) * 1000; // نصف قطر منطقة الرؤية (متر)
    return FlutterMap(
      options: MapOptions(
        initialCenter: mapCenter,
        initialZoom: mapZoom,
        onPositionChanged: (cam, _) {
          mapCenter = cam.center;
          mapZoom = cam.zoom;
        },
      ),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: appId),
        CircleLayer(circles: [
          CircleMarker(
              point: pos,
              radius: foot,
              useRadiusInMeter: true,
              color: Colors.deepOrange.withOpacity(0.12),
              borderColor: Colors.deepOrange,
              borderStrokeWidth: 1.5),
        ]),
        PolylineLayer(polylines: [
          for (final l in _past) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange.withOpacity(0.35)),
          for (final l in _fut) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange),
        ]),
        MarkerLayer(markers: [
          Marker(point: pos, width: 36, height: 36, child: const Icon(Icons.satellite_alt, color: Colors.red, size: 32)),
          Marker(point: LatLng(sel.lat, sel.lon), width: 30, height: 30, child: const Icon(Icons.location_on, color: ink)),
        ]),
        const SimpleAttributionWidget(source: Text('OpenStreetMap contributors')),
      ],
    );
  }

  Widget recsTab() => ListView(padding: const EdgeInsets.all(12), children: [
        const Card(
            child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                    'التسجيلات بصيغة WAV (16-bit أحادي). اضغط مشاركة لإرسالها أو حفظها، '
                    'ثم افتحها في برنامج فك SSTV (مثل MMSSTV أو QSSTV على الحاسوب) لاستخراج الصورة.',
                    style: TextStyle(fontSize: 12)))),
        if (recs.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('لا توجد تسجيلات بعد'))),
        for (final f in recs)
          Card(
            child: ListTile(
              leading: const Icon(Icons.audiotrack),
              title: Text(_recTitle(f), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 13)),
              subtitle: Text(_recInfo(f), style: const TextStyle(fontSize: 12)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(icon: const Icon(Icons.share), onPressed: () => Share.shareXFiles([XFile(f.path)])),
                IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _del(f)),
              ]),
            ),
          ),
      ]);

  @override
  Widget build(BuildContext c) {
    final dock = listening && tab == 0;
    final dockH = (MediaQuery.of(c).size.height * 0.38).clamp(240.0, 380.0).toDouble();
    final Widget body = switch (tab) {
      0 => listenTab(),
      1 => stationsTab(),
      2 => mapTab(),
      _ => recsTab(),
    };
    return Scaffold(
      appBar: AppBar(
        title: const Text('ISS SSTV Tracker'),
        actions: [
          if (recording)
            const Padding(padding: EdgeInsets.all(16), child: Icon(Icons.fiber_manual_record, color: Colors.red, size: 14)),
        ],
      ),
      body: Stack(children: [
        Padding(padding: EdgeInsets.only(bottom: dock ? dockH : 0), child: body),
        // نفس الـ WebView دائمًا (لا يُعاد إنشاؤه): لوحة ظاهرة في تبويب الاستماع، وبكسل واحد في غيره كي يستمر الصوت
        Positioned(
          left: 0,
          bottom: 0,
          right: dock ? 0 : null,
          width: dock ? null : 1,
          height: dock ? dockH : 1,
          child: Opacity(opacity: dock ? 1 : 0.01, child: ClipRect(child: WebViewWidget(controller: wc))),
        ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) {
          setState(() => tab = i);
          if (i == 3) _loadRecs();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.headphones), label: 'الاستماع'),
          NavigationDestination(icon: Icon(Icons.cell_tower), label: 'المحطات'),
          NavigationDestination(icon: Icon(Icons.public), label: 'الخريطة'),
          NavigationDestination(icon: Icon(Icons.library_music), label: 'التسجيلات'),
        ],
      ),
    );
  }
}
