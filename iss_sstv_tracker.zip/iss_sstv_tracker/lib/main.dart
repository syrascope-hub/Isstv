import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

const f0 = 437550000.0; // ISS SSTV downlink (راجع التردد قبل كل حدث)
const rad = math.pi / 180;
const minEl = 5.0; // أقل ارتفاع يُعتبر مرورًا صالحًا (درجات)
const appId = 'com.astro.iss_sstv_tracker';
const cream = Color(0xFFF5EFDC), ink = Color(0xFF111111);

class St {
  final String n, u;
  final bool ws;
  final double? la, lo;
  final bool approx; // إحداثيات تقريبية (على مستوى المدينة/الدولة) — صحّحها إن عرفت الموقع
  bool? ok;
  St(this.n, this.u, {this.ws = false, this.la, this.lo, this.approx = false});
  double get lat => la ?? 52.129;
  double get lon => lo ?? 5.019;
}

final stations = <St>[
  St('Maarssen NL — الأساسية', 'http://radarmaarssen.nl:8073/', la: 52.129, lo: 5.019),
  St('Maasbree WebSDR NL — احتياطي', 'http://sdr.websdrmaasbree.nl:8909/', ws: true, la: 51.35, lo: 6.05),
  St('fm-tuner ZZE3 NL', 'https://fm-tuner.nl/sdr-zze3/', la: 52.1, lo: 5.3, approx: true),
  St('DC7JZB Berlin', 'http://90.187.72.177:8073/', la: 52.408, lo: 13.404),
  St('DB0BLX Berlin', 'http://hamnetberlin.duckdns.org:4038/', la: 52.510, lo: 13.394),
  St('Dannenberg DE', 'http://hgdyn.spdns.org:8099/', la: 53.107, lo: 11.107),
  St('DC5DM Netphen DE', 'http://www.dc5dm.de/webrx/', la: 50.886, lo: 8.139),
  St('Hahnenkamm DE', 'http://sdr-hahnenkamm.de:8071/', la: 49.017, lo: 10.749),
  St('Grzegórzki PL', 'http://sdr.noip.pl:8073/', la: 50.018, lo: 19.979),
  St('SR4DON Olsztyn PL', 'https://1.websdr.jestok.com/', la: 53.78, lo: 20.49, approx: true),
  St('IW2KPL IT', 'http://www.dxcluster.world:8074/', la: 45.46, lo: 9.19, approx: true),
];

class V {
  final double x, y, z;
  V(this.x, this.y, this.z);
  V operator -(V o) => V(x - o.x, y - o.y, z - o.z);
  double get l => math.sqrt(x * x + y * y + z * z);
  double dot(V o) => x * o.x + y * o.y + z * o.z;
}

V obsV(double la, double lo) => V(6371 * math.cos(la * rad) * math.cos(lo * rad),
    6371 * math.cos(la * rad) * math.sin(lo * rad), 6371 * math.sin(la * rad));

class Pass {
  final double aos, los, maxEl;
  Pass(this.aos, this.los, this.maxEl);
}

class Look {
  final double el, az, rng;
  Look(this.el, this.az, this.rng);
}

/// مدار شبه دائري من TLE + انجراف J2 (تقريبي، مناسب للمرورات وDoppler).
class Orb {
  late final double inc, raan, argp, m0, n, ep, a, k;
  Orb(String l1, String l2) {
    double d(int s, int e) => double.parse(l2.substring(s, e).trim());
    inc = d(8, 16) * rad;
    raan = d(17, 25) * rad;
    argp = d(34, 42) * rad;
    m0 = d(43, 51) * rad;
    n = d(52, 63) * 2 * math.pi / 86400;
    final y = int.parse(l1.substring(18, 20));
    ep = DateTime.utc(y < 57 ? 2000 + y : 1900 + y).millisecondsSinceEpoch / 1000 +
        (double.parse(l1.substring(20, 32)) - 1) * 86400;
    a = math.pow(398600.4418 / (n * n), 1 / 3).toDouble();
    k = 1.5 * 1.08263e-3 * math.pow(6378.137 / a, 2).toDouble();
  }

  V ecef(double t) {
    final dt = t - ep;
    final c = math.cos(inc);
    final om = raan - k * n * c * dt;
    final u = m0 + argp + n * (1 + k * (4 * c * c - 1)) * dt;
    final x = a * (math.cos(om) * math.cos(u) - math.sin(om) * c * math.sin(u));
    final y = a * (math.sin(om) * math.cos(u) + math.cos(om) * c * math.sin(u));
    final z = a * math.sin(inc) * math.sin(u);
    final g = ((280.46061837 + 360.98564736629 * (t / 86400 + 2440587.5 - 2451545.0)) % 360) * rad;
    return V(x * math.cos(g) + y * math.sin(g), -x * math.sin(g) + y * math.cos(g), z);
  }

  LatLng ll(double t) {
    final s = ecef(t);
    return LatLng(math.asin(s.z / s.l) / rad, math.atan2(s.y, s.x) / rad);
  }

  double alt(double t) => ecef(t).l - 6371;

  double el(double t, V ob) {
    final r = ecef(t) - ob;
    return math.asin(r.dot(ob) / (r.l * ob.l)) / rad;
  }

  /// الارتفاع والسمت والمسافة من موقع المراقب.
  Look look(double t, double la, double lo) {
    final r = ecef(t) - obsV(la, lo);
    final sl = math.sin(la * rad), cl = math.cos(la * rad);
    final so = math.sin(lo * rad), co = math.cos(lo * rad);
    final e = -so * r.x + co * r.y;
    final nn = -sl * co * r.x - sl * so * r.y + cl * r.z;
    final u = cl * co * r.x + cl * so * r.y + sl * r.z;
    final rng = r.l;
    return Look(math.asin(u / rng) / rad, (math.atan2(e, nn) / rad + 360) % 360, rng);
  }

  double dop(double t, V ob) {
    final r1 = (ecef(t) - ob).l, r2 = (ecef(t + 1) - ob).l;
    return f0 * (1 - (r2 - r1) / 299792.458);
  }

  /// لحظة عبور الارتفاع [lv] بين a وb بالتنصيف (دقة أقل من ثانية).
  double _cross(V ob, double t1, double t2, double lv) {
    final sideA = el(t1, ob) > lv;
    for (int i = 0; i < 12; i++) {
      final m = (t1 + t2) / 2;
      if ((el(m, ob) > lv) == sideA) {
        t1 = m;
      } else {
        t2 = m;
      }
    }
    return (t1 + t2) / 2;
  }

  List<Pass> passes(double la, double lo, double t0, {double hours = 48}) {
    final ob = obsV(la, lo);
    final out = <Pass>[];
    double? aos;
    double mx = 0;
    double pt = t0, pe = el(t0, ob);
    if (pe > minEl) {
      aos = t0;
      mx = pe;
    }
    for (double t = t0 + 20; t < t0 + hours * 3600; t += 20) {
      final e = el(t, ob);
      if (aos == null && e > minEl && pe <= minEl) aos = _cross(ob, pt, t, minEl);
      if (e > minEl) mx = math.max(mx, e);
      if (aos != null && e <= minEl && pe > minEl) {
        out.add(Pass(aos, _cross(ob, pt, t, minEl), mx));
        aos = null;
        mx = 0;
      }
      pt = t;
      pe = e;
    }
    return out;
  }
}

final fln = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzd.initializeTimeZones();
  await fln.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  await fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    themeMode: ThemeMode.system, // يتبع نظام الجهاز
    theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: ink, surface: cream),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: cream),
        appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: cream)),
    darkTheme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange, brightness: Brightness.dark, surface: ink),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF1C1C1C)),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF1C1C1C), foregroundColor: cream)),
    builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
    home: const Home(),
  ));
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _S();
}

class _S extends State<Home> {
  int tab = 0;
  Orb? o;
  St sel = stations[0];
  List<Pass> ps = [];
  bool auto = true, listening = false;
  String err = '';
  double? cmd;
  final log = <String>[];
  late final WebViewController wc;
  SharedPreferences? sp;
  Timer? tk;

  // كاش مسار الخريطة (يُعاد حسابه كل 30 ثانية فقط)
  double _trackT = 0;
  List<List<LatLng>> _past = [], _fut = [];
  LatLng mapCenter = LatLng(45, 10);
  double mapZoom = 2.5;

  double get now => DateTime.now().millisecondsSinceEpoch / 1000;
  V get ob => obsV(sel.lat, sel.lon);

  @override
  void initState() {
    super.initState();
    wc = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted);
    final p = wc.platform;
    if (p is AndroidWebViewController) p.setMediaPlaybackRequiresUserGesture(false);
    wc.setNavigationDelegate(NavigationDelegate(onPageFinished: (_) => wc.runJavaScript(
        "setTimeout(function(){var b=document.getElementById('openwebrx-big-grey');if(b)b.click();},3000)")));
    _init();
    for (final s in stations) {
      http.get(Uri.parse(s.u)).timeout(const Duration(seconds: 6)).then((r) {
        if (mounted) setState(() => s.ok = r.statusCode < 400);
      }).catchError((_) {
        if (mounted) setState(() => s.ok = false);
      });
    }
    int i = 0;
    tk = Timer.periodic(const Duration(seconds: 1), (_) {
      i++;
      if (listening && auto && o != null && !sel.ws && i % 2 == 0) {
        final tg = (o!.dop(now, ob) / 100).round() * 100.0;
        final nc = cmd == null ? tg : cmd! + (tg - cmd!).clamp(-300.0, 300.0);
        final r = (nc / 100).round() * 100.0;
        if (r != cmd) {
          cmd = r;
          log.insert(0, '${DateTime.now().toString().substring(11, 19)}  ${(r / 1e6).toStringAsFixed(4)} MHz');
          if (log.length > 50) log.removeLast();
          wc.runJavaScript("location.hash='#freq=${r.round()},mod=nfm'");
        }
      }
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    tk?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  Future<void> _init() async {
    sp = await SharedPreferences.getInstance();
    final i = sp!.getInt('sel') ?? 0;
    if (i >= 0 && i < stations.length) sel = stations[i];
    await loadTle();
  }

  Orb? _parseTle(String body) {
    final l = body.split('\n').map((e) => e.trim()).toList();
    final a = l.where((e) => e.startsWith('1 ') && e.length >= 62).toList();
    final b = l.where((e) => e.startsWith('2 ') && e.length >= 63).toList();
    if (a.isEmpty || b.isEmpty) return null;
    return Orb(a.first, b.first);
  }

  /// يستخدم TLE المخزَّن إن كان أحدث من 6 ساعات، وإلا يجلب من CelesTrak،
  /// وعند الفشل يرجع للمخزَّن مهما كان عمره.
  Future<void> loadTle() async {
    final cached = sp?.getString('tle');
    final age = DateTime.now().millisecondsSinceEpoch - (sp?.getInt('tle_t') ?? 0);
    try {
      if (cached != null && age < 6 * 3600 * 1000) {
        final c = _parseTle(cached);
        if (c != null) {
          o = c;
          err = '';
          await refresh();
          return;
        }
      }
      final r = await http
          .get(Uri.parse('https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=tle'))
          .timeout(const Duration(seconds: 15));
      final fresh = _parseTle(r.body);
      if (fresh == null) throw Exception('رد غير صالح');
      await sp?.setString('tle', r.body);
      await sp?.setInt('tle_t', DateTime.now().millisecondsSinceEpoch);
      o = fresh;
      err = '';
    } catch (e) {
      final c = cached == null ? null : _parseTle(cached);
      if (c != null) {
        o = c;
        err = 'تعذر تحديث TLE — استُخدمت نسخة مخزَّنة (قد تقل الدقة)';
      } else {
        if (mounted) setState(() => err = 'تعذر تحميل TLE: $e');
        return;
      }
    }
    await refresh();
  }

  Future<void> _sched(int id, String title, String body, double when) async {
    try {
      await fln.zonedSchedule(
          id,
          title,
          body,
          tz.TZDateTime.from(DateTime.fromMillisecondsSinceEpoch((when * 1000).round()), tz.UTC),
          const NotificationDetails(
              android: AndroidNotificationDetails('iss', 'مرور ISS', importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } catch (_) {}
  }

  Future<void> refresh() async {
    if (o == null) return;
    ps = o!.passes(sel.lat, sel.lon, now);
    try {
      await fln.cancelAll();
    } catch (_) {}
    int id = 1;
    for (final p in ps.take(5)) {
      if (p.aos - 1800 > now) {
        await _sched(id++, 'ISS بعد 30 دقيقة',
            'ستمر ISS فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°. جهّز الاستماع على ${(f0 / 1e6).toStringAsFixed(3)}', p.aos - 1800);
      }
      if (p.aos > now) {
        await _sched(id++, 'ISS تبدأ الآن', 'بدأ المرور فوق ${sel.n} — أقصى ارتفاع ${p.maxEl.round()}°', p.aos);
      }
    }
    if (mounted) setState(() {});
  }

  void listen() {
    final f = o?.dop(now, ob) ?? f0;
    final u = sel.ws ? '${sel.u}?tune=${(f / 1e6).toStringAsFixed(3)}fm' : '${sel.u}#freq=${f.round()},mod=nfm';
    wc.loadRequest(Uri.parse(u));
    WakelockPlus.enable(); // يُبقي الشاشة شغّالة كي لا يتوقف الصوت
    setState(() {
      listening = true;
      cmd = null;
    });
  }

  void stop() {
    wc.loadRequest(Uri.parse('about:blank'));
    WakelockPlus.disable();
    setState(() {
      listening = false;
      cmd = null;
    });
  }

  void pick(St s) {
    if (listening) stop();
    sel = s;
    sp?.setInt('sel', stations.indexOf(s));
    refresh();
    setState(() {});
  }

  String fmt(double t) => DateTime.fromMillisecondsSinceEpoch((t * 1000).round()).toString().substring(5, 16);

  String dur(double s) {
    s = s.abs();
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, c = (s % 60).floor();
    return h > 0 ? '$hس ${m}د' : '$mد ${c}ث';
  }

  Widget stationsTab() => ListView(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text('الدائرة الخضراء = الصفحة تعمل فقط، ولا تضمن أن المستقبِل يغطي نطاق 70cm. '
              'علامة (≈) = إحداثيات تقريبية.', style: TextStyle(fontSize: 12)),
        ),
        for (final s in stations)
          ListTile(
            leading: Icon(Icons.circle, size: 14, color: s.ok == null ? Colors.grey : (s.ok! ? Colors.green : Colors.red)),
            title: Text(s.approx ? '${s.n} ≈' : s.n),
            subtitle: Text(s.u, textDirection: TextDirection.ltr),
            trailing: s == sel ? const Icon(Icons.check) : null,
            onTap: () => pick(s),
          ),
      ]);

  List<List<LatLng>> _segs(List<LatLng> pts) {
    final lines = <List<LatLng>>[[]];
    for (final p in pts) {
      if (lines.last.isNotEmpty && (p.longitude - lines.last.last.longitude).abs() > 180) lines.add([]);
      lines.last.add(p);
    }
    return lines;
  }

  Widget mapTab() {
    if (o == null) return Center(child: Text(err.isEmpty ? 'جارٍ تحميل مدار ISS...' : err));
    final t = now;
    if (t - _trackT > 30) {
      _trackT = t;
      _past = _segs([for (double d = -2700; d <= 0; d += 60) o!.ll(t + d)]);
      _fut = _segs([for (double d = 0; d <= 6000; d += 60) o!.ll(t + d)]);
    }
    final pos = o!.ll(t);
    final h = o!.alt(t);
    final foot = 6371 * math.acos(6371 / (6371 + h)) * 1000; // نصف قطر منطقة الرؤية (متر)
    return FlutterMap(
      options: MapOptions(
        initialCenter: mapCenter,
        initialZoom: mapZoom,
        onPositionChanged: (cam, _) {
          mapCenter = cam.center;
          mapZoom = cam.zoom;
        },
      ),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: appId),
        CircleLayer(circles: [
          CircleMarker(
              point: pos,
              radius: foot,
              useRadiusInMeter: true,
              color: Colors.deepOrange.withOpacity(0.12),
              borderColor: Colors.deepOrange,
              borderStrokeWidth: 1.5),
        ]),
        PolylineLayer(polylines: [
          for (final l in _past) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange.withOpacity(0.35)),
          for (final l in _fut) Polyline(points: l, strokeWidth: 2, color: Colors.deepOrange),
        ]),
        MarkerLayer(markers: [
          Marker(point: pos, width: 36, height: 36, child: const Icon(Icons.satellite_alt, color: Colors.red, size: 32)),
          Marker(point: LatLng(sel.lat, sel.lon), width: 30, height: 30, child: const Icon(Icons.location_on, color: ink)),
        ]),
        const SimpleAttributionWidget(source: Text('OpenStreetMap contributors')),
      ],
    );
  }

  Widget listenTab() {
    final t = now;
    final f = o?.dop(t, ob) ?? f0;
    final lk = o?.look(t, sel.lat, sel.lon);
    final next = ps.where((p) => p.los > t).toList();
    String cd = '';
    if (next.isNotEmpty) {
      final p = next.first;
      cd = p.aos <= t ? '● المرور جارٍ — ينتهي بعد ${dur(p.los - t)}' : 'المرور القادم بعد ${dur(p.aos - t)}';
    }
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(sel.n, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (err.isNotEmpty) Text(err, style: const TextStyle(color: Colors.red)),
      if (cd.isNotEmpty) Text(cd, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      Text('التردد المحسوب (Doppler): ${(f / 1e6).toStringAsFixed(4)} MHz', textDirection: TextDirection.ltr),
      if (lk != null) ...[
        Text('ارتفاع ISS: ${lk.el.toStringAsFixed(1)}°  ${lk.el > 0 ? "● فوق الأفق" : "○ تحت الأفق"}'),
        Text('السمت: ${lk.az.toStringAsFixed(0)}°   المسافة: ${lk.rng.round()} كم'),
      ],
      SwitchListTile(value: auto, onChanged: (v) => setState(() => auto = v), title: const Text('ضبط Doppler تلقائيًا (OpenWebRX)')),
      if (sel.ws) const Text('Maasbree: الضبط التلقائي غير متاح، يُضبط التردد عند البدء فقط.'),
      Row(children: [
        Expanded(child: FilledButton(onPressed: listen, child: Text(listening ? 'إعادة الاتصال' : 'ابدأ الاستماع'))),
        if (listening) ...[
          const SizedBox(width: 8),
          OutlinedButton(onPressed: stop, child: const Text('إيقاف')),
        ],
      ]),
      if (listening) const Padding(padding: EdgeInsets.only(top: 6), child: Text('الشاشة تبقى مضاءة أثناء الاستماع.', style: TextStyle(fontSize: 12))),
      if (log.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Text('سجل الترددات المرسلة:'),
        for (final l in log.take(5)) Text(l, textDirection: TextDirection.ltr),
      ],
      const Divider(height: 32),
      Text('المرورات القادمة (ارتفاع ≥ ${minEl.round()}°، إشعار قبل 30 دقيقة وعند البدء):',
          style: const TextStyle(fontWeight: FontWeight.bold)),
      for (final p in next.take(6))
        ListTile(
            dense: true,
            title: Text('${fmt(p.aos)} → ${fmt(p.los)}'),
            subtitle: Text('أقصى ارتفاع ≈ ${p.maxEl.round()}°  •  المدة ${dur(p.los - p.aos)}')),
    ]);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('ISS SSTV Tracker')),
        body: Stack(children: [
          // نبني التبويب الحالي فقط حتى لا تُحسب الخريطة كل ثانية دون داعٍ
          [stationsTab, mapTab, listenTab][tab](),
          Positioned(left: 0, top: 0, width: 1, height: 1, child: Opacity(opacity: 0.01, child: WebViewWidget(controller: wc))),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.cell_tower), label: 'المحطات'),
            NavigationDestination(icon: Icon(Icons.public), label: 'الخريطة'),
            NavigationDestination(icon: Icon(Icons.headphones), label: 'الاستماع'),
          ],
        ),
      );
}
